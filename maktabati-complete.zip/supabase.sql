-- مكتبتي الإلكترونية: قاعدة البيانات المقترحة لـ Supabase
create extension if not exists pgcrypto;

create table if not exists public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 avatar_url text,
 created_at timestamptz not null default now()
);

create table if not exists public.books(
 id uuid primary key default gen_random_uuid(),
 owner_id uuid references auth.users(id) on delete set null,
 title text not null,
 author text not null,
 kind text not null check(kind in ('كتاب','ملزمة')),
 description text not null default '',
 is_free boolean not null default true,
 price_iqd integer not null default 0 check(price_iqd >= 0),
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 cover_path text,
 pdf_path text,
 cover_color text default 'green',
 created_at timestamptz not null default now()
);

create unique index if not exists books_title_author_unique on public.books(lower(title),lower(author));

create table if not exists public.submissions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 title text not null,
 author text not null,
 kind text not null check(kind in ('كتاب','ملزمة')),
 is_free boolean not null default true,
 price integer not null default 0,
 description text not null default '',
 pdf_path text,
 cover_path text,
 rights_confirmed boolean not null default false,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 admin_note text,
 created_at timestamptz not null default now()
);

create table if not exists public.favorites(
 user_id uuid not null references auth.users(id) on delete cascade,
 book_id uuid not null references public.books(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_id,book_id)
);

create table if not exists public.payments(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 book_id uuid not null references public.books(id) on delete cascade,
 method text not null check(method in ('zaincash','superqi')),
 amount_iqd integer not null,
 receipt_path text,
 status text not null default 'pending' check(status in ('pending','approved','rejected')),
 created_at timestamptz not null default now()
);

create table if not exists public.admins(user_id uuid primary key references auth.users(id) on delete cascade);

create table if not exists public.purchases(
 user_id uuid not null references auth.users(id) on delete cascade,
 book_id uuid not null references public.books(id) on delete cascade,
 payment_id uuid references public.payments(id) on delete set null,
 created_at timestamptz not null default now(),
 primary key(user_id,book_id)
);

alter table public.profiles enable row level security;
alter table public.books enable row level security;
alter table public.submissions enable row level security;
alter table public.favorites enable row level security;
alter table public.payments enable row level security;
alter table public.purchases enable row level security;

create policy "public approved books" on public.books for select using (status='approved' and is_free=true);
create policy "admins can read all books" on public.books for select to authenticated using (exists(select 1 from public.admins a where a.user_id=auth.uid()));
create policy "admins can create approved books" on public.books for insert to authenticated with check (exists(select 1 from public.admins a where a.user_id=auth.uid()));
create policy "admins can update books" on public.books for update to authenticated using (exists(select 1 from public.admins a where a.user_id=auth.uid())) with check (exists(select 1 from public.admins a where a.user_id=auth.uid()));
create policy "owners can read their books" on public.books for select to authenticated using (owner_id=auth.uid());
create policy "users submit own" on public.submissions for insert to authenticated with check(user_id=auth.uid() and rights_confirmed=true);
create policy "users read own submissions" on public.submissions for select to authenticated using(user_id=auth.uid());
create policy "favorites own read" on public.favorites for select to authenticated using(user_id=auth.uid());
create policy "favorites own add" on public.favorites for insert to authenticated with check(user_id=auth.uid());
create policy "favorites own delete" on public.favorites for delete to authenticated using(user_id=auth.uid());
create policy "payments own" on public.payments for select to authenticated using(user_id=auth.uid());
create policy "payments create own" on public.payments for insert to authenticated with check(user_id=auth.uid());
create policy "purchases own" on public.purchases for select to authenticated using(user_id=auth.uid());

create policy "admins read submissions" on public.submissions for select to authenticated using (user_id=auth.uid() or exists(select 1 from public.admins a where a.user_id=auth.uid()));
create policy "admins update submissions" on public.submissions for update to authenticated using (exists(select 1 from public.admins a where a.user_id=auth.uid())) with check (exists(select 1 from public.admins a where a.user_id=auth.uid()));

insert into storage.buckets(id,name,public) values('library-files','library-files',false) on conflict(id) do nothing;
create policy "authenticated upload own library files" on storage.objects for insert to authenticated with check(bucket_id='library-files' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "owners read own library files" on storage.objects for select to authenticated using(bucket_id='library-files' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "admins read library files" on storage.objects for select to authenticated using(bucket_id='library-files' and exists(select 1 from public.admins a where a.user_id=auth.uid()));
-- لا تضع service_role key في ملفات الموقع.

create or replace function public.handle_new_user() returns trigger language plpgsql security definer as $$
begin insert into public.profiles(id,display_name,avatar_url) values(new.id,coalesce(new.raw_user_meta_data->>'user_name',new.email),new.raw_user_meta_data->>'avatar_url') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

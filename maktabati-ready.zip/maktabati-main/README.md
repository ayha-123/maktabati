# maktabati

مكتبة إلكترونية للكتب والملازم الدراسية المجانية والمدفوعة.

## النشر
المشروع مهيأ للعمل على GitHub Pages: `https://ayha-123.github.io/maktabati/`

## تسجيل الدخول
الموقع يستخدم Supabase Auth مع GitHub OAuth. يجب إضافة `https://ayha-123.github.io/maktabati/` في Supabase Authentication → URL Configuration ضمن Site URL وRedirect URLs.

لا تضع Service Role Key أو GitHub Client Secret داخل ملفات الموقع.
